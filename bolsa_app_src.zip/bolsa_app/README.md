# Documentación de la Aplicación de Filtro de Acciones

## Descripción General

Esta aplicación web permite filtrar y visualizar datos de acciones de la Bolsa de Santiago en tiempo real. La aplicación utiliza un script de scraping para obtener los datos más recientes, y proporciona una interfaz intuitiva para filtrar y visualizar la información.

## Características Principales

1. **Interfaz de Usuario Responsiva**:
   - Diseño adaptable para dispositivos móviles y escritorio
   - Campos para ingresar hasta 5 códigos de acciones
   - Tabla de resultados con indicadores visuales

2. **Filtrado de Acciones**:
   - Búsqueda por códigos de acciones (nemos)
   - Persistencia de búsquedas anteriores
   - Botones para filtrar y limpiar campos

3. **Actualización de Datos**:
   - Actualización manual mediante botón
   - Actualización automática configurable (1-3 o 1-5 minutos)
   - Indicador de próxima actualización

4. **Visualización de Datos**:
   - Tabla con columnas para Acción, Precio, Variación, Compra, Venta, Monto, Moneda y Volumen
   - Indicadores visuales (flechas y colores) para variaciones positivas y negativas
   - Animación de actualización para cambios en los datos

## Estructura del Proyecto

```
bolsa_app/
├── venv/                  # Entorno virtual de Python
├── src/
│   ├── models/            # Modelos de datos (no utilizados en esta versión)
│   ├── routes/            # Rutas de la API
│   │   └── api.py         # Endpoints de la API
│   ├── scripts/           # Scripts de scraping y servicios
│   │   ├── __init__.py
│   │   ├── bolsa_santiago_bot.py  # Script de scraping
│   │   ├── har_analyzer.py        # Analizador de archivos HAR
│   │   └── bolsa_service.py       # Servicio para gestionar datos de acciones
│   ├── static/            # Archivos estáticos
│   │   ├── index.html     # Página principal
│   │   ├── styles.css     # Estilos CSS
│   │   └── app.js         # Lógica de frontend
│   └── main.py            # Punto de entrada de la aplicación
├── logs/                  # Directorio para logs
├── data/                  # Directorio para datos JSON
└── requirements.txt       # Dependencias de Python
```

## Requisitos

- Python 3.11 o superior
- Navegador web moderno (Chrome, Firefox, Edge, Safari)
- Conexión a Internet

## Instalación y Ejecución

1. **Preparación del entorno**:
   ```bash
   # Clonar el repositorio o descomprimir el archivo
   cd bolsa_app
   
   # Crear y activar entorno virtual
   python -m venv venv
   source venv/bin/activate  # En Windows: venv\Scripts\activate
   
   # Instalar dependencias
   pip install -r requirements.txt
   
   # Instalar navegadores para Playwright (necesario para el scraping)
   python -m playwright install
   ```

2. **Ejecución de la aplicación**:
   ```bash
   # Desde el directorio raíz del proyecto
   cd bolsa_app
   source venv/bin/activate  # En Windows: venv\Scripts\activate
   python src/main.py
   ```

3. **Acceso a la aplicación**:
   - Abrir un navegador web
   - Acceder a `http://localhost:5000`

## Uso de la Aplicación

1. **Filtrar Acciones**:
   - Ingresar hasta 5 códigos de acciones en los campos de texto
   - Hacer clic en "Filtrar" para mostrar los resultados
   - Los códigos se guardan automáticamente para futuras sesiones

2. **Actualización de Datos**:
   - Hacer clic en "Actualizar" para obtener los datos más recientes
   - Seleccionar un modo de actualización automática en el desplegable:
     - Desactivado: Sin actualización automática
     - Random 1-3 minutos: Actualización aleatoria entre 1 y 3 minutos
     - Random 1-5 minutos: Actualización aleatoria entre 1 y 5 minutos

3. **Visualización de Resultados**:
   - La tabla muestra los datos de las acciones filtradas
   - Las variaciones positivas se muestran en verde con flecha hacia arriba
   - Las variaciones negativas se muestran en rojo con flecha hacia abajo

## Notas Técnicas

- La aplicación utiliza Flask como backend y JavaScript puro para el frontend
- El scraping se realiza mediante Playwright, que automatiza un navegador Chrome
- Los datos se almacenan temporalmente en archivos JSON
- La actualización automática se gestiona tanto en el servidor como en el cliente

## Solución de Problemas

- **Error de autenticación**: Si aparecen errores relacionados con el login, verificar las credenciales en el archivo `bolsa_santiago_bot.py`
- **Datos no actualizados**: Hacer clic en "Actualizar" para forzar una actualización manual
- **Errores de scraping**: Revisar los logs en el directorio `logs/` para más información

## Limitaciones

- La aplicación depende de la estructura actual del sitio web de la Bolsa de Santiago
- Cambios en el sitio web podrían requerir actualizaciones en el script de scraping
- El rendimiento puede variar según la conexión a Internet y la carga del servidor

import os
import json
import logging
import time
from datetime import datetime
import threading
import subprocess
from pathlib import Path

# Configuración de logging
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler(os.path.join(LOG_DIR, "bolsa_service.log"), encoding='utf-8')
file_handler.setFormatter(logging.Formatter('[%(levelname)s] %(asctime)s - %(message)s'))
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter('[%(levelname)s] %(asctime)s - %(message)s'))
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

# Directorio para almacenar los datos JSON
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Archivo JSON más reciente
LATEST_JSON_FILE = os.path.join(DATA_DIR, "latest_acciones_data.json")

# Variable para controlar el hilo de actualización
update_thread = None
stop_update_thread = False

def run_bolsa_bot():
    """
    Ejecuta el script bolsa_santiago_bot.py y devuelve la ruta al archivo JSON generado
    """
    try:
        logger.info("Iniciando proceso de scraping de datos de la Bolsa de Santiago")
        
        # Directorio donde se encuentra el script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Ejecutar el script como un proceso separado
        process = subprocess.Popen(
            ["python3", os.path.join(script_dir, "bolsa_santiago_bot.py")],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=script_dir
        )
        
        # Esperar a que termine el proceso
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            logger.error(f"Error al ejecutar el script: {stderr}")
            return None
        
        # Buscar el archivo JSON más reciente en el directorio de logs
        logs_dir = os.path.join(script_dir, "logs_bolsa")
        if not os.path.exists(logs_dir):
            logger.error(f"El directorio de logs no existe: {logs_dir}")
            return None
        
        json_files = [f for f in os.listdir(logs_dir) if f.startswith("acciones-precios-plus_") and f.endswith(".json")]
        if not json_files:
            logger.error("No se encontraron archivos JSON generados")
            return None
        
        # Ordenar por fecha de modificación (más reciente primero)
        latest_json = sorted(json_files, key=lambda x: os.path.getmtime(os.path.join(logs_dir, x)), reverse=True)[0]
        json_path = os.path.join(logs_dir, latest_json)
        
        # Copiar el archivo JSON más reciente al directorio de datos
        with open(json_path, 'r', encoding='utf-8') as src_file:
            json_data = json.load(src_file)
            
        with open(LATEST_JSON_FILE, 'w', encoding='utf-8') as dest_file:
            json.dump(json_data, dest_file, indent=2, ensure_ascii=False)
        
        logger.info(f"Datos actualizados correctamente: {LATEST_JSON_FILE}")
        return LATEST_JSON_FILE
    
    except Exception as e:
        logger.exception(f"Error en run_bolsa_bot: {e}")
        return None

def get_latest_data():
    """
    Obtiene los datos más recientes del archivo JSON
    """
    try:
        if not os.path.exists(LATEST_JSON_FILE):
            logger.warning("No existe archivo de datos. Ejecutando scraping...")
            run_bolsa_bot()
            
        if os.path.exists(LATEST_JSON_FILE):
            with open(LATEST_JSON_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # Añadir timestamp de la última actualización
            data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return data
        else:
            logger.error("No se pudo obtener datos actualizados")
            return {"error": "No se pudieron obtener datos", "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    
    except Exception as e:
        logger.exception(f"Error en get_latest_data: {e}")
        return {"error": str(e), "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

def filter_stocks(stock_codes):
    """
    Filtra las acciones según los códigos proporcionados
    """
    try:
        data = get_latest_data()
        if "error" in data:
            return data
        
        # Convertir códigos a mayúsculas para comparación insensible a mayúsculas/minúsculas
        stock_codes = [code.upper() for code in stock_codes if code.strip()]
        
        # Filtrar las acciones
        filtered_data = []
        
        # Verificar la estructura del JSON y extraer los datos relevantes
        if "data" in data and isinstance(data["data"], list):
            stocks = data["data"]
        elif isinstance(data, list):
            stocks = data
        else:
            logger.error(f"Estructura de datos inesperada: {type(data)}")
            return {"error": "Estructura de datos inesperada", "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        
        for stock in stocks:
            if "nemo" in stock and stock["nemo"] in stock_codes:
                filtered_data.append(stock)
        
        result = {
            "data": filtered_data,
            "timestamp": data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        }
        
        return result
    
    except Exception as e:
        logger.exception(f"Error en filter_stocks: {e}")
        return {"error": str(e), "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

def update_data_periodically(min_interval, max_interval):
    """
    Actualiza los datos periódicamente en un intervalo aleatorio
    """
    global stop_update_thread
    
    while not stop_update_thread:
        try:
            run_bolsa_bot()
            # Calcular intervalo aleatorio en segundos
            interval = int(min_interval + (max_interval - min_interval) * random.random())
            logger.info(f"Próxima actualización en {interval} segundos")
            
            # Esperar el intervalo, verificando periódicamente si debemos detenernos
            for _ in range(interval):
                if stop_update_thread:
                    break
                time.sleep(1)
                
        except Exception as e:
            logger.exception(f"Error en la actualización periódica: {e}")
            time.sleep(60)  # Esperar un minuto antes de reintentar en caso de error

def start_periodic_updates(min_minutes=1, max_minutes=3):
    """
    Inicia la actualización periódica de datos en un hilo separado
    """
    global update_thread, stop_update_thread
    
    if update_thread and update_thread.is_alive():
        logger.info("Ya existe un hilo de actualización en ejecución")
        return False
    
    stop_update_thread = False
    min_interval = min_minutes * 60
    max_interval = max_minutes * 60
    
    update_thread = threading.Thread(
        target=update_data_periodically,
        args=(min_interval, max_interval),
        daemon=True
    )
    update_thread.start()
    
    logger.info(f"Iniciada actualización periódica (intervalo: {min_minutes}-{max_minutes} minutos)")
    return True

def stop_periodic_updates():
    """
    Detiene la actualización periódica de datos
    """
    global stop_update_thread
    
    stop_update_thread = True
    logger.info("Deteniendo actualizaciones periódicas")
    return True

# Asegurarse de que el módulo random esté importado
import random

from flask_sqlalchemy import SQLAlchemy

# Base de datos
db = SQLAlchemy()

# Import models to ensure they are registered with SQLAlchemy
from .user import User  # noqa: E402,F401
from .stock_price import StockPrice  # noqa: E402,F401
from .credentials import Credential  # noqa: E402,F401
from .column_preference import ColumnPreference  # noqa: E402,F401
from .stock_filter import StockFilter  # noqa: E402,F401
from .last_update import LastUpdate  # noqa: E402,F401
from .log_entry import LogEntry  # noqa: E402,F401

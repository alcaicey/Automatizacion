# Este archivo permite que el directorio scripts sea un paquete Python

import os
import json
import logging
import time
import subprocess
from datetime import datetime
import threading
import re
import glob

# Configuración de rutas personalizadas para Windows
SCRIPTS_DIR = r"C:\Users\alcai\Desktop\Acciones\Automatizacion"
LOGS_DIR = os.path.join(SCRIPTS_DIR, "logs_bolsa")

# Configuración de logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler("bolsa_service.log", encoding='utf-8')
file_handler.setFormatter(logging.Formatter('[%(levelname)s] %(asctime)s - %(message)s'))
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter('[%(levelname)s] %(asctime)s - %(message)s'))
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

# Variable para controlar el hilo de actualización
update_thread = None
stop_update_thread = False

def get_latest_json_file():
    """
    Obtiene el archivo JSON más reciente del directorio de logs
    """
    try:
        # Patrón para los archivos JSON
        pattern = os.path.join(LOGS_DIR, "acciones-precios-plus_*.json")
        
        # Obtener todos los archivos que coinciden con el patrón
        json_files = glob.glob(pattern)
        
        if not json_files:
            logger.error(f"No se encontraron archivos JSON en {LOGS_DIR}")
            return None
        
        # Ordenar por fecha de modificación (más reciente primero)
        latest_json = max(json_files, key=os.path.getmtime)
        
        logger.info(f"Archivo JSON más reciente encontrado: {latest_json}")
        return latest_json
    
    except Exception as e:
        logger.exception(f"Error al buscar el archivo JSON más reciente: {e}")
        return None

def extract_timestamp_from_filename(filename):
    """
    Extrae el timestamp del nombre del archivo
    Formato esperado: acciones-precios-plus_AAAAMMDD_HHMMSS.json
    """
    try:
        # Extraer el nombre base del archivo sin la ruta
        base_name = os.path.basename(filename)
        
        # Usar expresión regular para extraer la fecha y hora
        match = re.search(r'acciones-precios-plus_(\d{8})_(\d{6})\.json', base_name)
        
        if match:
            date_str = match.group(1)  # AAAAMMDD
            time_str = match.group(2)  # HHMMSS
            
            # Formatear como fecha legible
            year = date_str[0:4]
            month = date_str[4:6]
            day = date_str[6:8]
            
            hour = time_str[0:2]
            minute = time_str[2:4]
            second = time_str[4:6]
            
            formatted_timestamp = f"{day}/{month}/{year} {hour}:{minute}:{second}"
            return formatted_timestamp
        
        return datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    except Exception as e:
        logger.exception(f"Error al extraer timestamp del nombre de archivo: {e}")
        return datetime.now().strftime("%d/%m/%Y %H:%M:%S")

def run_bolsa_bot():
    """
    Ejecuta el script bolsa_santiago_bot.py y devuelve la ruta al archivo JSON generado
    """
    try:
        logger.info("Iniciando proceso de scraping de datos de la Bolsa de Santiago")
        
        # Ruta al script
        script_path = os.path.join(SCRIPTS_DIR, "bolsa_santiago_bot.py")
        
        # Verificar que el script existe
        if not os.path.exists(script_path):
            logger.error(f"El script no existe en la ruta especificada: {script_path}")
            return None
        
        # Ejecutar el script como un proceso separado
        process = subprocess.Popen(
            ["python", script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=SCRIPTS_DIR
        )
        
        # Esperar a que termine el proceso
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            logger.error(f"Error al ejecutar el script: {stderr}")
            return None
        
        # Buscar el archivo JSON más reciente
        latest_json = get_latest_json_file()
        
        if latest_json:
            logger.info(f"Datos actualizados correctamente: {latest_json}")
            return latest_json
        else:
            logger.error("No se encontró el archivo JSON generado")
            return None
    
    except Exception as e:
        logger.exception(f"Error en run_bolsa_bot: {e}")
        return None

def get_latest_data():
    """
    Obtiene los datos más recientes del archivo JSON
    """
    try:
        latest_json = get_latest_json_file()
        
        if not latest_json:
            logger.warning("No existe archivo de datos. Ejecutando scraping...")
            latest_json = run_bolsa_bot()
            
        if latest_json and os.path.exists(latest_json):
            with open(latest_json, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # Añadir timestamp de la última actualización
            timestamp = extract_timestamp_from_filename(latest_json)
            data["timestamp"] = timestamp
            return data
        else:
            logger.error("No se pudo obtener datos actualizados")
            return {"error": "No se pudieron obtener datos", "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S")}
    
    except Exception as e:
        logger.exception(f"Error en get_latest_data: {e}")
        return {"error": str(e), "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S")}

def filter_stocks(stock_codes):
    """
    Filtra las acciones según los códigos proporcionados
    """
    try:
        data = get_latest_data()
        if "error" in data:
            return data
        
        # Convertir códigos a mayúsculas para comparación insensible a mayúsculas/minúsculas
        stock_codes = [code.upper() for code in stock_codes if code.strip()]
        
        # Filtrar las acciones
        filtered_data = []
        
        # Verificar la estructura del JSON y extraer los datos relevantes
        if "data" in data and isinstance(data["data"], list):
            stocks = data["data"]
        elif isinstance(data, list):
            stocks = data
        else:
            logger.error(f"Estructura de datos inesperada: {type(data)}")
            return {"error": "Estructura de datos inesperada", "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S")}
        
        for stock in stocks:
            if "nemo" in stock and stock["nemo"] in stock_codes:
                filtered_data.append(stock)
        
        result = {
            "data": filtered_data,
            "timestamp": data.get("timestamp", datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
        }
        
        return result
    
    except Exception as e:
        logger.exception(f"Error en filter_stocks: {e}")
        return {"error": str(e), "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S")}

def update_data_periodically(min_interval, max_interval):
    """
    Actualiza los datos periódicamente en un intervalo aleatorio
    """
    global stop_update_thread
    
    while not stop_update_thread:
        try:
            run_bolsa_bot()
            # Calcular intervalo aleatorio en segundos
            interval = int(min_interval + (max_interval - min_interval) * random.random())
            logger.info(f"Próxima actualización en {interval} segundos")
            
            # Esperar el intervalo, verificando periódicamente si debemos detenernos
            for _ in range(interval):
                if stop_update_thread:
                    break
                time.sleep(1)
                
        except Exception as e:
            logger.exception(f"Error en la actualización periódica: {e}")
            time.sleep(60)  # Esperar un minuto antes de reintentar en caso de error

def start_periodic_updates(min_minutes=1, max_minutes=3):
    """
    Inicia la actualización periódica de datos en un hilo separado
    """
    global update_thread, stop_update_thread
    
    if update_thread and update_thread.is_alive():
        logger.info("Ya existe un hilo de actualización en ejecución")
        return False
    
    stop_update_thread = False
    min_interval = min_minutes * 60
    max_interval = max_minutes * 60
    
    update_thread = threading.Thread(
        target=update_data_periodically,
        args=(min_interval, max_interval),
        daemon=True
    )
    update_thread.start()
    
    logger.info(f"Iniciada actualización periódica (intervalo: {min_minutes}-{max_minutes} minutos)")
    return True

def stop_periodic_updates():
    """
    Detiene la actualización periódica de datos
    """
    global stop_update_thread
    
    stop_update_thread = True
    logger.info("Deteniendo actualizaciones periódicas")
    return True

# Asegurarse de que el módulo random esté importado
import random
